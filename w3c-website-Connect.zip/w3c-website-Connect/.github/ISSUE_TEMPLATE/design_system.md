---
name: Design System
about: Submit an issue about the W3C Design System
title: ''
labels: 'design system'
assignees: ''

---

**Describe the issue**
A clear and concise description of what the problem is.

**URL**
The URL where this problem occurs.

**Recommended solution**
A clear description of how you think the design system should be updated.

**Additional context**
Add any other context about the problem here.

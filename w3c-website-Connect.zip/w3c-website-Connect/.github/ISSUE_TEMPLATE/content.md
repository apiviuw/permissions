---
name: Content
about: Submit an issue about W3C website content
title: ''
labels: content
assignees: ''

---

**Describe the issue**
A clear and concise description of what the problem is.

**URL**
The URL where this problem occurs.

**Recommended solution**
A clear description of how you think the content should be updated.

**Additional context**
Add any other context about the problem here.
